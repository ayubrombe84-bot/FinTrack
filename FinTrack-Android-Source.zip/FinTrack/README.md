# FinTrack Android

FinTrack is a native Android starter app for personal finance tracking, written in Java with a dark Material-style interface and SQLite local storage.

## Included in this starter
- Income and expense entries stored locally on the device.
- Balance summary and recent transaction list.
- Savings goals with progress and add-to-goal action.
- Aggregate income/expense report.
- Investment compound-growth simulator with risk disclaimer.
- Indonesian Rupiah formatting.

## Important current limitations
- This is an initial offline-capable starter, not a production-ready financial service.
- Online account login and cloud synchronization are not implemented yet. They require a secure backend, authentication, encrypted transport, conflict handling, and a clear privacy policy. Local data remains on-device in this version.
- Investment figures are educational estimates only; no investment orders, live market prices, or guaranteed returns are provided.
- Reports currently show all recorded transactions, not date-filtered monthly reports.

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Requirements: Android Studio with Android SDK 35 and JDK 17. Application ID: `com.fintrack.app`.
